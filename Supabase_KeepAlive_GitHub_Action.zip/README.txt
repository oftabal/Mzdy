Rozbal do kořene repozitáře Mzdy.
Commitni změny a pushni je na GitHub.
Workflow poběží každých 6 hodin nebo jej lze spustit ručně v záložce Actions.
